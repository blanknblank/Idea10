import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { MemoryProvider } from './contexts/MemoryContext';
import { PetProvider } from './contexts/PetContext';
import { CommunityProvider } from './contexts/CommunityContext';

import Home from './pages/Home';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import MemoryPage from './pages/MemoryPage';
import PetPage from './pages/PetPage';
import CommunityPage from './pages/CommunityPage';

function App() {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('darkMode') === 'true';
  });

  useEffect(() => {
    document.body.className = darkMode ? 'dark' : '';
    localStorage.setItem('darkMode', darkMode);
  }, [darkMode]);

  return (
    <AuthProvider>
      <MemoryProvider>
        <PetProvider>
          <CommunityProvider>
            <Router>
              <div>
                <button onClick={() => setDarkMode(prev => !prev)}>
                  Toggle {darkMode ? 'Light' : 'Dark'} Mode
                </button>
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/register" element={<RegisterPage />} />
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/memory" element={<MemoryPage />} />
                  <Route path="/pet" element={<PetPage />} />
                  <Route path="/community" element={<CommunityPage />} />
                </Routes>
              </div>
            </Router>
          </CommunityProvider>
        </PetProvider>
      </MemoryProvider>
    </AuthProvider>
  );
}

export default App;
